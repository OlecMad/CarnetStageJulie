/* Carnet de stage - cache hors ligne (version web uniquement ; l'APK n'enregistre pas ce fichier).
   Changer VERSION a chaque mise a jour pour renouveler le cache. */
var VERSION = 'carnet-julie-mvaoe-v0.2.0';
var FICHIERS = ['./', 'index.html', 'app.js', 'store.js', 'hw.js', 'dictee.js', 'schema.js', 'export.js',
  'profil.js', 'vendor/docx/docx.min.js', 'manifest.json', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/apple-touch-icon.png'];
self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(VERSION).then(function (c) { return c.addAll(FICHIERS); }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (ks) {
    return Promise.all(ks.filter(function (k) { return k !== VERSION; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then(function (r) { return r || fetch(e.request); }));
});
