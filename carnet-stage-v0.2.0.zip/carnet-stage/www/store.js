/* Carnet de stage - stockage local (IndexedDB) et utilitaires de dates.
   Magasins : notes, photos, schemas (cle : id), meta (cle : k). */
(function (root) {
  'use strict';

  var RUBRIQUES = (root.Profil && root.Profil.rubriques) ? root.Profil.rubriques.slice() : ['Libre'];

  var STORES = ['notes', 'photos', 'schemas'];
  var db = null;
  var mem = null; // repli en memoire si IndexedDB est indisponible

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function jourLocal(d) { d = d || new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function heureLocale(d) { return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()); }
  function dateFr(iso) { var p = String(iso).slice(0, 10).split('-'); return p[2] + '/' + p[1] + '/' + p[0]; }
  function horodatageFr(d) { return dateFr(jourLocal(d)) + ' ' + heureLocale(d); }
  function newId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

  function open() {
    return new Promise(function (res) {
      var idb = root.indexedDB;
      if (!idb) { mem = { notes: {}, photos: {}, schemas: {}, meta: {} }; return res(); }
      var rq;
      try { rq = idb.open((root.Profil && root.Profil.id && root.Profil.id !== 'acsagri') ? 'carnet-stage-' + root.Profil.id : 'carnet-stage', 1); } catch (e) { mem = { notes: {}, photos: {}, schemas: {}, meta: {} }; return res(); }
      rq.onupgradeneeded = function () {
        var d = rq.result;
        STORES.forEach(function (s) { if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { keyPath: 'id' }); });
        if (!d.objectStoreNames.contains('meta')) d.createObjectStore('meta', { keyPath: 'k' });
      };
      rq.onsuccess = function () { db = rq.result; res(); };
      rq.onerror = function () { mem = { notes: {}, photos: {}, schemas: {}, meta: {} }; res(); };
    });
  }

  function tx(store, mode, fn) {
    return new Promise(function (res, rej) {
      var t = db.transaction(store, mode);
      var out = fn(t.objectStore(store));
      t.oncomplete = function () { res(out && out.result !== undefined ? out.result : undefined); };
      t.onerror = function () { rej(t.error); };
      t.onabort = function () { rej(t.error || new Error('transaction annulee')); };
    });
  }

  function put(store, obj) {
    if (mem) { mem[store][obj.id || obj.k] = obj; return Promise.resolve(obj); }
    return tx(store, 'readwrite', function (s) { return s.put(obj); }).then(function () { return obj; });
  }
  function del(store, id) {
    if (mem) { delete mem[store][id]; return Promise.resolve(); }
    return tx(store, 'readwrite', function (s) { return s.delete(id); });
  }
  function all(store) {
    if (mem) return Promise.resolve(Object.keys(mem[store]).map(function (k) { return mem[store][k]; }));
    return tx(store, 'readonly', function (s) { return s.getAll(); });
  }
  function get(store, id) {
    if (mem) return Promise.resolve(mem[store][id]);
    return tx(store, 'readonly', function (s) { return s.get(id); });
  }
  function getMeta(k, dflt) { return get('meta', k).then(function (o) { return o ? o.v : dflt; }); }
  function setMeta(k, v) { return put('meta', { k: k, v: v }); }

  function persist() {
    try { if (root.navigator && navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (e) { /* facultatif */ }
  }

  /* Sauvegarde / restauration complete (JSON). */
  function exportAll() {
    return Promise.all([all('notes'), all('photos'), all('schemas'), all('meta')]).then(function (r) {
      return { format: 'carnet-stage', version: 1, exporteLe: new Date().toISOString(), notes: r[0], photos: r[1], schemas: r[2], meta: r[3] };
    });
  }
  function importAll(o) {
    if (!o || o.format !== 'carnet-stage') return Promise.reject(new Error('Fichier de sauvegarde non reconnu'));
    var jobs = [];
    STORES.forEach(function (s) { (o[s] || []).forEach(function (x) { if (x && x.id) jobs.push(put(s, x)); }); });
    (o.meta || []).forEach(function (x) { if (x && x.k) jobs.push(put('meta', x)); });
    return Promise.all(jobs).then(function () { return jobs.length; });
  }

  root.Store = {
    RUBRIQUES: RUBRIQUES, open: open, put: put, del: del, all: all, get: get, getMeta: getMeta, setMeta: setMeta,
    persist: persist, exportAll: exportAll, importAll: importAll,
    jourLocal: jourLocal, heureLocale: heureLocale, dateFr: dateFr, horodatageFr: horodatageFr, newId: newId
  };
})(typeof window !== 'undefined' ? window : globalThis);
