/* Carnet de stage - éditeur de schémas à main levée (canvas, événements pointeur).
   Les tracés sont gardés sous forme vectorielle (réédition possible) ; un PNG est produit
   pour l'export .docx. Annuler/rétablir par instantanés de la liste des tracés. */
(function (root) {
  'use strict';
  var W0 = 1200, H0 = 800;

  function Editor(canvas) {
    this.cv = canvas; this.ctx = canvas.getContext('2d'); this.W = W0; this.H = H0; this.bg = null;
    this.strokes = []; this.hist = [[]]; this.hi = 0;
    this.tool = 'pen'; this.color = '#1d2a22'; this.size = 3; this.grid = true;
    this.cur = null; this.textPending = null; this.textPos = null;
    var self = this;
    function pos(e) {
      var r = canvas.getBoundingClientRect();
      return [(e.clientX - r.left) * self.W / r.width, (e.clientY - r.top) * self.H / r.height];
    }
    canvas.addEventListener('pointerdown', function (e) {
      e.preventDefault();
      try { canvas.setPointerCapture(e.pointerId); } catch (x) { /* facultatif */ }
      var p = pos(e);
      if (self.tool === 'text') { self.placeText(p); return; }
      if (self.tool === 'erase') { self.erasing = true; self.eraseAt(p); return; }
      self.cur = self.tool === 'pen'
        ? { t: 'pen', c: self.color, w: self.size, pts: [p] }
        : { t: self.tool, c: self.color, w: self.size, a: p, b: p };
      self.render();
    });
    canvas.addEventListener('pointermove', function (e) {
      var p = pos(e);
      if (self.erasing) { self.eraseAt(p); return; }
      if (!self.cur) return;
      if (self.cur.t === 'pen') self.cur.pts.push(p); else self.cur.b = p;
      self.render();
    });
    function up() {
      if (self.erasing) { self.erasing = false; if (self.erased) { self.erased = false; self.commit(); } return; }
      if (!self.cur) return;
      var s = self.cur; self.cur = null;
      if (s.t === 'pen' && s.pts.length === 1) s.pts.push([s.pts[0][0] + 0.1, s.pts[0][1] + 0.1]); // point
      self.strokes.push(s); self.commit();
    }
    canvas.addEventListener('pointerup', up);
    canvas.addEventListener('pointercancel', up);
    this.render();
  }

  var P = Editor.prototype;

  P.commit = function () {
    this.hist = this.hist.slice(0, this.hi + 1);
    this.hist.push(this.strokes.slice());
    this.hi = this.hist.length - 1;
    this.render();
  };
  P.undo = function () { if (this.hi > 0) { this.hi--; this.strokes = this.hist[this.hi].slice(); this.render(); } };
  P.redo = function () { if (this.hi < this.hist.length - 1) { this.hi++; this.strokes = this.hist[this.hi].slice(); this.render(); } };
  P.clear = function () { if (this.strokes.length) { this.strokes = []; this.commit(); } };
  P.load = function (strokes) { this.strokes = (strokes || []).slice(); this.hist = [this.strokes.slice()]; this.hi = 0; this.render(); };
  P.setGrid = function (g) { this.grid = !!g; this.render(); };

  P.placeText = function (p) {
    if (!this.textPending) return;
    this.strokes.push({ t: 'text', c: this.color, w: this.size, x: p[0], y: p[1], s: this.textPending });
    this.textPending = null;
    this.commit();
  };

  /* Gomme : retire les tracés touchés par le point p (rayon proportionnel). */
  P.eraseAt = function (p) {
    var r = 22, n0 = this.strokes.length;
    this.strokes = this.strokes.filter(function (s) { return !hit(s, p, r); });
    if (this.strokes.length !== n0) { this.erased = true; this.render(); }
  };

  function dseg(p, a, b) {
    var dx = b[0] - a[0], dy = b[1] - a[1], l2 = dx * dx + dy * dy;
    var t = l2 ? Math.max(0, Math.min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / l2)) : 0;
    var x = a[0] + t * dx - p[0], y = a[1] + t * dy - p[1];
    return Math.sqrt(x * x + y * y);
  }
  function hit(s, p, r) {
    var i, a, b;
    if (s.t === 'pen') { for (i = 0; i < s.pts.length - 1; i++) if (dseg(p, s.pts[i], s.pts[i + 1]) <= r) return true; return false; }
    if (s.t === 'line') return dseg(p, s.a, s.b) <= r;
    if (s.t === 'rect') {
      a = s.a; b = s.b;
      var c = [[a[0], a[1]], [b[0], a[1]], [b[0], b[1]], [a[0], b[1]]];
      for (i = 0; i < 4; i++) if (dseg(p, c[i], c[(i + 1) % 4]) <= r) return true;
      return false;
    }
    if (s.t === 'ellipse') {
      var cx = (s.a[0] + s.b[0]) / 2, cy = (s.a[1] + s.b[1]) / 2, rx = Math.abs(s.b[0] - s.a[0]) / 2, ry = Math.abs(s.b[1] - s.a[1]) / 2;
      var pts = [];
      for (i = 0; i < 48; i++) pts.push([cx + rx * Math.cos(i * Math.PI / 24), cy + ry * Math.sin(i * Math.PI / 24)]);
      for (i = 0; i < 48; i++) if (dseg(p, pts[i], pts[(i + 1) % 48]) <= r) return true;
      return false;
    }
    if (s.t === 'text') { var fs = fontSize(s); return p[0] >= s.x - r && p[0] <= s.x + s.s.length * fs * 0.6 + r && p[1] >= s.y - fs - r && p[1] <= s.y + r; }
    return false;
  }
  function fontSize(s) { return 14 + s.w * 3; }

  function draw(ctx, s) {
    ctx.strokeStyle = s.c; ctx.fillStyle = s.c; ctx.lineWidth = s.w; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (s.t === 'pen') {
      ctx.beginPath(); ctx.moveTo(s.pts[0][0], s.pts[0][1]);
      for (var i = 1; i < s.pts.length; i++) ctx.lineTo(s.pts[i][0], s.pts[i][1]);
      ctx.stroke();
    } else if (s.t === 'line') {
      ctx.beginPath(); ctx.moveTo(s.a[0], s.a[1]); ctx.lineTo(s.b[0], s.b[1]); ctx.stroke();
    } else if (s.t === 'rect') {
      ctx.strokeRect(Math.min(s.a[0], s.b[0]), Math.min(s.a[1], s.b[1]), Math.abs(s.b[0] - s.a[0]), Math.abs(s.b[1] - s.a[1]));
    } else if (s.t === 'ellipse') {
      ctx.beginPath();
      ctx.ellipse((s.a[0] + s.b[0]) / 2, (s.a[1] + s.b[1]) / 2, Math.abs(s.b[0] - s.a[0]) / 2 || 1, Math.abs(s.b[1] - s.a[1]) / 2 || 1, 0, 0, Math.PI * 2);
      ctx.stroke();
    } else if (s.t === 'text') {
      ctx.font = fontSize(s) + 'px sans-serif'; ctx.fillText(s.s, s.x, s.y);
    }
  }

  /* Fond photo : le canevas prend les proportions de la photo (largeur max 1280). */
  P.setBackground = function (dataUrl, w, h) {
    var self = this;
    return new Promise(function (res, rej) {
      var im = new root.Image();
      im.onload = function () {
        var iw = w || im.naturalWidth || 4, ih = h || im.naturalHeight || 3, k = Math.min(1, 1280 / iw);
        self.W = Math.round(iw * k); self.H = Math.round(ih * k);
        self.cv.width = self.W; self.cv.height = self.H;
        self.cv.style.aspectRatio = self.W + ' / ' + self.H;
        self.bg = im; self.strokes = []; self.hist = [[]]; self.hi = 0; self.render(); res();
      };
      im.onerror = function () { rej(new Error('Photo illisible')); };
      im.src = dataUrl;
    });
  };
  P.clearBackground = function () {
    this.bg = null; this.W = W0; this.H = H0; this.cv.width = W0; this.cv.height = H0;
    this.cv.style.aspectRatio = '3 / 2'; this.strokes = []; this.hist = [[]]; this.hi = 0; this.render();
  };
  P.hasBackground = function () { return !!this.bg; };

  P.render = function () {
    var c = this.ctx, W = this.W, H = this.H;
    c.fillStyle = '#ffffff'; c.fillRect(0, 0, W, H);
    if (this.bg) c.drawImage(this.bg, 0, 0, W, H);
    if (this.grid && !this.bg) {
      c.strokeStyle = '#e3e8e1'; c.lineWidth = 1; c.beginPath();
      for (var x = 40; x < W; x += 40) { c.moveTo(x, 0); c.lineTo(x, H); }
      for (var y = 40; y < H; y += 40) { c.moveTo(0, y); c.lineTo(W, y); }
      c.stroke();
    }
    for (var i = 0; i < this.strokes.length; i++) draw(c, this.strokes[i]);
    if (this.cur) draw(c, this.cur);
  };

  /* PNG sans grille (la grille sert au guidage, pas au document). */
  P.toPng = function () {
    var g = this.grid; this.grid = false; this.cur = null; this.render();
    var url = this.cv.toDataURL('image/png');
    this.grid = g; this.render();
    return url;
  };
  /* Photo annotee : JPEG (photo + traits). */
  P.toJpeg = function () { this.cur = null; this.render(); return this.cv.toDataURL('image/jpeg', 0.85); };
  P.isEmpty = function () { return this.strokes.length === 0; };

  root.SchemaEditor = Editor;
  root.SchemaEditor.SIZE = [W0, H0];
})(typeof window !== 'undefined' ? window : globalThis);
