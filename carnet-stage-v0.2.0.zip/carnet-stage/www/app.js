/* Carnet de stage - interface. */
(function (root) {
  'use strict';
  var doc = root.document;
  var S = root.Store;
  function $(id) { return doc.getElementById(id); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  var PR = root.Profil || { titre: 'Carnet de stage', fichier: 'Carnet_de_stage', objJours: 40 };
  var ST = { annotPhoto: null, jour: S.jourLocal(), stage: {}, joursStage: [], editNote: null, editSchema: null, data: { notes: [], photos: [], schemas: [] } };
  var editor = null;

  function msg(id, text, isErr) {
    var el = $(id); if (!el) return;
    el.innerHTML = text ? '<div class="msg' + (isErr ? ' err' : '') + '">' + esc(text) + '</div>' : '';
  }

  /* ---------- donnees ---------- */
  function reload() {
    return Promise.all([S.all('notes'), S.all('photos'), S.all('schemas'), S.getMeta('stage', {}), S.getMeta('joursStage', [])]).then(function (r) {
      ST.data = { notes: r[0], photos: r[1], schemas: r[2] };
      ST.stage = Object.assign({}, PR.defauts || {}, r[3] || {}); ST.joursStage = r[4] || [];
      refresh();
    });
  }
  function byTime(a, b) { return a.creeLe < b.creeLe ? -1 : a.creeLe > b.creeLe ? 1 : 0; }
  function ofDay(list, j) { return list.filter(function (x) { return x.jour === j; }).sort(byTime); }
  function hhmm(iso) { return S.heureLocale(new Date(iso)); }

  /* ---------- navigation ---------- */
  function show(p) {
    ['journal', 'noter', 'photo', 'schema', 'export', 'reglages'].forEach(function (n) {
      $('p-' + n).hidden = n !== p;
    });
    [].forEach.call(doc.querySelectorAll('#onglets button'), function (b) { b.setAttribute('aria-selected', b.dataset.p === p ? 'true' : 'false'); });
    if (p === 'export') renderExport();
    if (p === 'schema') editor.render();
  }

  /* ---------- listes ---------- */
  function delButton(label, fn) {
    var b = doc.createElement('button'); b.className = 'btn dang'; b.textContent = label;
    var armed = false, t = null;
    b.onclick = function () {
      if (!armed) { armed = true; b.textContent = 'Confirmer ?'; t = setTimeout(function () { armed = false; b.textContent = label; }, 3000); return; }
      clearTimeout(t); fn();
    };
    return b;
  }
  function cardNote(n) {
    var c = doc.createElement('div'); c.className = 'card';
    c.innerHTML = '<div class="t">' + hhmm(n.creeLe) + ' <span class="tag">' + esc(n.rubrique) + '</span></div><div>' + esc(n.texte).replace(/\n/g, '<br>') + '</div>';
    var row = doc.createElement('div'); row.className = 'row'; row.style.marginTop = '6px';
    var e = doc.createElement('button'); e.className = 'btn sec'; e.textContent = 'Modifier';
    e.onclick = function () { ST.editNote = n.id; $('n-rub').value = n.rubrique; $('n-texte').value = n.texte; show('noter'); msg('n-msg', 'Modification d\'une note du ' + S.dateFr(n.jour) + ' à ' + hhmm(n.creeLe) + '.'); };
    row.appendChild(e);
    row.appendChild(delButton('Supprimer', function () { S.del('notes', n.id).then(reload); }));
    c.appendChild(row); return c;
  }
  function cardPhoto(p) {
    var c = doc.createElement('div'); c.className = 'card';
    c.innerHTML = '<div class="t">' + hhmm(p.creeLe) + ' <span class="tag">' + esc(p.rubrique) + '</span>' + (p.legende ? ' - ' + esc(p.legende) : '') + '</div><img alt="Photo du ' + esc(S.horodatageFr(new Date(p.creeLe))) + '" src="' + p.data + '">';
    var row = doc.createElement('div'); row.className = 'row'; row.style.marginTop = '6px';
    var an = doc.createElement('button'); an.className = 'btn sec'; an.textContent = p.annote ? 'Modifier l\'annotation' : 'Annoter';
    an.onclick = function () { openAnnot(p); };
    row.appendChild(an);
    row.appendChild(delButton('Supprimer', function () { S.del('photos', p.id).then(reload); }));
    c.appendChild(row); return c;
  }
  function cardSchema(s) {
    var c = doc.createElement('div'); c.className = 'card';
    c.innerHTML = '<div class="t">' + hhmm(s.creeLe) + ' <span class="tag">' + esc(s.rubrique) + '</span> - ' + esc(s.titre || 'Sans titre') + '</div><img alt="Schéma ' + esc(s.titre) + '" src="' + s.png + '">';
    var row = doc.createElement('div'); row.className = 'row'; row.style.marginTop = '6px';
    var e = doc.createElement('button'); e.className = 'btn sec'; e.textContent = 'Rouvrir';
    e.onclick = function () { ST.editSchema = s.id; $('s-titre').value = s.titre || ''; $('s-rub').value = s.rubrique; editor.load(s.traits); show('schema'); msg('s-msg', 'Schéma rouvert. Enregistrer remplace la version précédente.'); };
    row.appendChild(e);
    row.appendChild(delButton('Supprimer', function () { S.del('schemas', s.id).then(reload); }));
    c.appendChild(row); return c;
  }
  function fill(id, list, fn, empty) {
    var el = $(id); el.innerHTML = '';
    if (!list.length) { el.innerHTML = '<p class="mut">' + empty + '</p>'; return; }
    list.forEach(function (x) { el.appendChild(fn(x)); });
  }

  function refresh() {
    var j = ST.jour;
    var obj = parseInt(ST.stage.obj, 10) || PR.objJours;
    $('compteur').textContent = 'Jours : ' + ST.joursStage.length + ' / ' + obj;
    var isStage = ST.joursStage.indexOf(j) >= 0;
    var b = $('j-stage'); b.textContent = 'Jour de stage : ' + (isStage ? 'oui' : 'non'); b.setAttribute('aria-pressed', isStage ? 'true' : 'false');
    var box = $('j-contenu'); box.innerHTML = '';
    var n = ofDay(ST.data.notes, j), p = ofDay(ST.data.photos, j), s = ofDay(ST.data.schemas, j);
    if (!n.length && !p.length && !s.length) box.innerHTML = '<p class="mut">Rien de noté ce jour.</p>';
    n.forEach(function (x) { box.appendChild(cardNote(x)); });
    p.forEach(function (x) { box.appendChild(cardPhoto(x)); });
    s.forEach(function (x) { box.appendChild(cardSchema(x)); });
    fill('n-liste', n, cardNote, 'Aucune note aujourd\'hui.');
    fill('ph-liste', p, cardPhoto, 'Aucune photo aujourd\'hui.');
    fill('s-liste', s, cardSchema, 'Aucun schéma aujourd\'hui.');

    var days = {};
    ['notes', 'photos', 'schemas'].forEach(function (k) { ST.data[k].forEach(function (x) { (days[x.jour] = days[x.jour] || { notes: 0, photos: 0, schemas: 0 })[k]++; }); });
    ST.joursStage.forEach(function (d) { days[d] = days[d] || { notes: 0, photos: 0, schemas: 0 }; });
    var t = '<tr><th>Jour</th><th>Stage</th><th>Notes</th><th>Photos</th><th>Schémas</th></tr>';
    Object.keys(days).sort().reverse().forEach(function (d) {
      t += '<tr data-j="' + d + '"><td>' + S.dateFr(d) + '</td><td>' + (ST.joursStage.indexOf(d) >= 0 ? 'oui' : '') + '</td><td>' + days[d].notes + '</td><td>' + days[d].photos + '</td><td>' + days[d].schemas + '</td></tr>';
    });
    $('journal-liste').innerHTML = t;
    [].forEach.call(doc.querySelectorAll('#journal-liste tr[data-j]'), function (tr) {
      tr.style.cursor = 'pointer';
      tr.onclick = function () { ST.jour = tr.dataset.j; $('j-date').value = ST.jour; refresh(); };
    });
  }

  /* ---------- notes ---------- */
  function fillRubriques() {
    ['n-rub', 'ph-rub', 's-rub'].forEach(function (id) {
      $(id).innerHTML = S.RUBRIQUES.map(function (r) { return '<option>' + esc(r) + '</option>'; }).join('');
    });
  }
  function saveNote() {
    if (root.Dictee.actif()) root.Dictee.arreter();
    var texte = $('n-texte').value.trim();
    if (!texte) { msg('n-msg', 'La note est vide.', true); return; }
    var prev = ST.editNote ? ST.data.notes.filter(function (x) { return x.id === ST.editNote; })[0] : null;
    var o = prev ? { id: prev.id, jour: prev.jour, creeLe: prev.creeLe, modifieLe: new Date().toISOString() } : { id: S.newId(), jour: ST.jour, creeLe: new Date().toISOString() };
    o.rubrique = $('n-rub').value; o.texte = texte;
    S.put('notes', o).then(function () {
      ST.editNote = null; $('n-texte').value = ''; S.setMeta('brouillon', '');
      msg('n-msg', 'Note enregistrée.'); return reload();
    }).catch(function (e) { msg('n-msg', 'Enregistrement impossible : ' + e.message, true); });
  }
  function setupDictee() {
    var btn = $('n-mic'), ta = $('n-texte');
    var hooks = {
      onState: function (on) { btn.textContent = on ? 'Arrêter la dictée' : (root.HW.IOS && !root.HW.NATIVE ? 'Dicter (micro du clavier)' : 'Dicter'); btn.classList.toggle('rec', !!on); },
      onMessage: function (m, err) { msg('n-msg', m, err); },
      onText: function (v) { S.setMeta('brouillon', v); },
      onDone: function (v) { S.setMeta('brouillon', v); if (!$('n-msg').textContent) msg('n-msg', 'Dictée terminée. Relire, corriger au besoin, puis enregistrer.'); },
      onUnavailable: function () { $('n-popup').hidden = false; }
    };
    btn.onclick = function () { msg('n-msg', ''); root.Dictee.demarrer(ta, hooks); };
    $('n-popup').onclick = function () { msg('n-msg', ''); root.Dictee.popup(ta, hooks); };
    $('n-save').onclick = saveNote;
    ta.addEventListener('input', function () { S.setMeta('brouillon', ta.value); });
    if (root.HW.NATIVE && root.HW.plug('SpeechRecognition')) $('n-popup').hidden = false;
    if (root.HW.IOS && !root.HW.NATIVE) btn.textContent = 'Dicter (micro du clavier)';
  }

  /* ---------- photos ---------- */
  function stampPhoto(dataUrl, date) {
    return new Promise(function (res) {
      var im = new root.Image();
      im.onload = function () {
        try {
          var w = im.naturalWidth, h = im.naturalHeight, cv = doc.createElement('canvas');
          cv.width = w; cv.height = h;
          var c = cv.getContext('2d'); c.drawImage(im, 0, 0, w, h);
          var fs = Math.max(14, Math.round(w / 40)), txt = S.horodatageFr(date);
          c.font = 'bold ' + fs + 'px sans-serif';
          var tw = c.measureText(txt).width + fs;
          c.fillStyle = 'rgba(0,0,0,.55)'; c.fillRect(0, h - fs * 1.9, tw, fs * 1.9);
          c.fillStyle = '#fff'; c.fillText(txt, fs / 2, h - fs * 0.6);
          res({ data: cv.toDataURL('image/jpeg', 0.8), w: w, h: h });
        } catch (e) { res({ data: dataUrl, w: im.naturalWidth, h: im.naturalHeight }); }
      };
      im.onerror = function () { res({ data: dataUrl, w: 0, h: 0 }); };
      im.src = dataUrl;
    });
  }
  function takePhoto() {
    msg('ph-msg', '');
    root.HW.takePhoto().then(function (u) {
      var now = new Date();   // instant de retour de l'appareil photo
      return stampPhoto(u, now).then(function (r) {
        var o = { id: S.newId(), jour: S.jourLocal(now), creeLe: now.toISOString(), rubrique: $('ph-rub').value, legende: $('ph-leg').value.trim(), data: r.data, w: r.w, h: r.h };
        return S.put('photos', o).then(function () { return o; });
      });
    }).then(function (o) {
      $('ph-leg').value = '';
      return reload().then(function () {
        $('ph-msg').innerHTML = '<div class="msg">Photo enregistrée avec la date et l\'heure. <button class="btn sec" id="ph-annoter" style="margin-top:6px">Annoter cette photo</button></div>';
        $('ph-annoter').onclick = function () { openAnnot(o); };
      });
    })
      .catch(function (e) { if (!/annul|cancel/i.test(String(e && e.message))) msg('ph-msg', 'Photo impossible : ' + (e && e.message || 'erreur'), true); });
  }

  /* ---------- schémas ---------- */
  /* ---------- annotation d'une photo (le schéma sert d'éditeur, la photo en fond) ---------- */
  function openAnnot(p) {
    ST.annotPhoto = p.id; ST.editSchema = null;
    return editor.setBackground(p.orig || p.data, p.w, p.h).then(function () {
      if (p.traits && p.traits.length) editor.load(p.traits);
      $('s-meta').hidden = true; $('s-annot').hidden = false;
      $('s-annot-txt').textContent = 'Annotation de la photo du ' + S.horodatageFr(new Date(p.creeLe)) + '.';
      $('s-save').textContent = 'Enregistrer l\'annotation';
      msg('s-msg', '');
      show('schema');
    }).catch(function (e) { msg('ph-msg', 'Annotation impossible : ' + e.message, true); });
  }
  function exitAnnot() {
    ST.annotPhoto = null; editor.clearBackground();
    $('s-meta').hidden = false; $('s-annot').hidden = true; $('s-save').textContent = 'Enregistrer le schéma';
  }
  function saveAnnot() {
    var p = ST.data.photos.filter(function (x) { return x.id === ST.annotPhoto; })[0];
    if (!p) { msg('s-msg', 'Photo introuvable.', true); return; }
    var o = {}; Object.keys(p).forEach(function (k) { o[k] = p[k]; });
    if (editor.isEmpty()) { if (p.orig) { o.data = p.orig; } o.traits = []; o.annote = false; }
    else { o.orig = p.orig || p.data; o.traits = editor.strokes.slice(); o.data = editor.toJpeg(); o.annote = true; o.w = editor.W; o.h = editor.H; }
    S.put('photos', o).then(function () { exitAnnot(); msg('ph-msg', 'Annotation enregistrée sur la photo.'); show('photo'); return reload(); })
      .catch(function (e) { msg('s-msg', 'Enregistrement impossible : ' + e.message, true); });
  }

  function setupSchema() {
    editor = new root.SchemaEditor($('canvas'));
    function pressed(sel, el) { [].forEach.call(doc.querySelectorAll(sel), function (b) { b.setAttribute('aria-pressed', b === el ? 'true' : 'false'); }); }
    [].forEach.call(doc.querySelectorAll('#s-outils button'), function (b) {
      b.onclick = function () { editor.tool = b.dataset.tool; pressed('#s-outils button', b); $('s-texte-ligne').hidden = b.dataset.tool !== 'text'; };
    });
    [].forEach.call(doc.querySelectorAll('#s-couleurs .sw'), function (b) { b.onclick = function () { editor.color = b.dataset.c; pressed('#s-couleurs .sw', b); }; });
    [].forEach.call(doc.querySelectorAll('#s-couleurs [data-size]'), function (b) { b.onclick = function () { editor.size = parseInt(b.dataset.size, 10); pressed('#s-couleurs [data-size]', b); }; });
    $('s-couleurs').querySelector('[data-fond]').onclick = function () { var b = this; editor.setGrid(b.getAttribute('aria-pressed') !== 'true'); b.setAttribute('aria-pressed', editor.grid ? 'true' : 'false'); };
    $('s-poser').onclick = function () { var t = $('s-texte').value.trim(); if (t) { editor.textPending = t; msg('s-msg', 'Toucher le schéma à l\'endroit voulu pour poser le texte.'); } };
    $('s-undo').onclick = function () { editor.undo(); };
    $('s-redo').onclick = function () { editor.redo(); };
    $('s-clear').onclick = function () { editor.clear(); };
    $('s-annot-quit').onclick = function () { exitAnnot(); show('photo'); };
    $('s-save').onclick = function () {
      if (ST.annotPhoto) { saveAnnot(); return; }
      if (editor.isEmpty()) { msg('s-msg', 'Le schéma est vide.', true); return; }
      var prev = ST.editSchema ? ST.data.schemas.filter(function (x) { return x.id === ST.editSchema; })[0] : null;
      var o = prev ? { id: prev.id, jour: prev.jour, creeLe: prev.creeLe, modifieLe: new Date().toISOString() } : { id: S.newId(), jour: ST.jour, creeLe: new Date().toISOString() };
      o.rubrique = $('s-rub').value; o.titre = $('s-titre').value.trim(); o.traits = editor.strokes.slice(); o.png = editor.toPng(); o.w = root.SchemaEditor.SIZE[0]; o.h = root.SchemaEditor.SIZE[1];
      S.put('schemas', o).then(function () { ST.editSchema = null; editor.load([]); $('s-titre').value = ''; msg('s-msg', 'Schéma enregistré.'); return reload(); })
        .catch(function (e) { msg('s-msg', 'Enregistrement impossible : ' + e.message, true); });
    };
  }

  /* ---------- export ---------- */
  function renderExport() {
    var du = $('e-du').value, au = $('e-au').value, r = root.Export.resume(ST.data, du, au);
    $('e-resume').textContent = r.notes + ' notes, ' + r.photos + ' photos, ' + r.schemas + ' schémas sur la période.';
  }
  function doExport() {
    msg('e-msg', 'Génération en cours…');
    $('e-go').disabled = true;
    var data = { notes: ST.data.notes, photos: ST.data.photos, schemas: ST.data.schemas, stage: ST.stage, joursStage: ST.joursStage };
    root.Export.build(data, { du: $('e-du').value, au: $('e-au').value, org: $('e-org').value })
      .then(root.Export.toBlob)
      .then(function (blob) { return root.HW.saveBlob(PR.fichier + '_' + S.jourLocal() + '.docx', blob, PR.titre, $('e-msg')); })
      .then(function (name) { msg('e-msg', 'Fichier ' + name + (root.HW.NATIVE ? ' enregistré dans Documents.' : ' enregistré.')); })
      .catch(function (e) { msg('e-msg', 'Génération impossible : ' + (e && e.message || 'erreur'), true); })
      .then(function () { $('e-go').disabled = false; });
  }

  /* ---------- réglages ---------- */
  function fillStage() {
    var s = ST.stage;
    $('r-nom').value = s.nom || ''; $('r-expl').value = s.expl || ''; $('r-lieu').value = s.lieu || ''; $('r-maitre').value = s.maitre || '';
    $('r-debut').value = s.debut || ''; $('r-fin').value = s.fin || ''; $('r-obj').value = s.obj || String(PR.objJours);
  }
  function saveStage() {
    var s = { nom: $('r-nom').value.trim(), expl: $('r-expl').value.trim(), lieu: $('r-lieu').value.trim(), maitre: $('r-maitre').value.trim(),
      debut: $('r-debut').value, fin: $('r-fin').value, obj: String(parseInt($('r-obj').value, 10) || PR.objJours) };
    S.setMeta('stage', s).then(reload).then(function () { msg('r-msg', 'Réglages enregistrés.'); });
  }
  function renderLog(lines) { $('dlog').textContent = lines.length ? lines.join('\n') : 'Aucun événement.'; $('dlog').scrollTop = 1e9; }
  function setupDiag() {
    root.Dictee.setOnLog(renderLog);
    renderLog(root.Dictee.journal());
    function pill(ok, t) { return '<span class="pill ' + (ok ? 'ok' : 'ko') + '">' + esc(t) + '</span>'; }
    $('d-etat').onclick = function () {
      $('d-etat-res').innerHTML = '<p class="mut">Vérification…</p>';
      root.Dictee.etat().then(function (o) {
        $('d-etat-res').innerHTML = '<p>' + pill(o.native, o.native ? 'Application Android' : 'Navigateur (pas l\'APK)') +
          pill(o.plugin, o.plugin ? 'Plugin de dictée présent' : 'Plugin de dictée absent') +
          pill(o.permission === 'granted', 'Micro : ' + o.permission) +
          pill(o.disponible === true, o.disponible === null ? 'Moteur : non testé' : o.disponible ? 'Moteur de reconnaissance présent' : 'Aucun moteur de reconnaissance') +
          (o.erreur ? pill(false, 'Erreur : ' + o.erreur) : '') + '</p>';
      });
    };
    $('d-essai').onclick = function () {
      var fake = { value: '' };
      var btn = $('d-essai'); btn.disabled = true;
      root.Dictee.demarrer(fake, { onMessage: function (m) { $('d-etat-res').innerHTML = '<div class="msg err">' + esc(m) + '</div>'; } }).then(function () {
        setTimeout(function () {
          root.Dictee.arreter();
          setTimeout(function () {
            btn.disabled = false;
            $('d-etat-res').insertAdjacentHTML('afterbegin', '<div class="msg">Texte reçu pendant l\'essai : ' + (fake.value ? '« ' + esc(fake.value) + ' »' : 'aucun') + '</div>');
          }, 3300);
        }, 10000);
      });
    };
    $('b-export').onclick = function () {
      S.exportAll().then(function (o) { return root.HW.saveText(PR.fichier + '_sauvegarde_' + S.jourLocal() + '.json', JSON.stringify(o), 'Sauvegarde du carnet', $('b-msg')); })
        .then(function (n) { msg('b-msg', 'Sauvegarde enregistrée : ' + n); })
        .catch(function (e) { msg('b-msg', 'Sauvegarde impossible : ' + (e && e.message), true); });
    };
    $('b-import').onclick = function () { $('b-file').click(); };
    $('b-file').onchange = function () {
      var f = $('b-file').files[0]; if (!f) return;
      var r = new root.FileReader();
      r.onload = function () {
        try { S.importAll(JSON.parse(String(r.result))).then(function (n) { msg('b-msg', n + ' éléments restaurés.'); return reload().then(fillStage); }).catch(function (e) { msg('b-msg', e.message, true); }); }
        catch (e) { msg('b-msg', 'Fichier illisible.', true); }
      };
      r.readAsText(f);
    };
  }

  /* ---------- démarrage ---------- */
  function init() {
    doc.title = PR.titre; var h = doc.querySelector('header h1'); if (h) h.textContent = PR.titre;
    fillRubriques(); setupDictee(); setupSchema(); setupDiag();
    [].forEach.call(doc.querySelectorAll('#onglets button'), function (b) { b.onclick = function () { show(b.dataset.p); }; });
    $('j-date').value = ST.jour;
    $('j-date').onchange = function () { ST.jour = $('j-date').value || S.jourLocal(); refresh(); };
    $('j-stage').onclick = function () {
      var i = ST.joursStage.indexOf(ST.jour);
      if (i >= 0) ST.joursStage.splice(i, 1); else ST.joursStage.push(ST.jour);
      ST.joursStage.sort(); S.setMeta('joursStage', ST.joursStage).then(refresh);
    };
    $('ph-take').onclick = takePhoto;
    $('e-go').onclick = doExport;
    $('e-du').onchange = renderExport; $('e-au').onchange = renderExport;
    $('r-save').onclick = saveStage;
    if (!root.HW.NATIVE && root.navigator && navigator.serviceWorker && /^https?:/.test(root.location.protocol)) { navigator.serviceWorker.register('sw.js').catch(function () { /* cache hors ligne facultatif */ }); }
    S.open().then(function () { S.persist(); return reload(); }).then(function () {
      fillStage();
      return S.getMeta('brouillon', '').then(function (b) { if (b) $('n-texte').value = b; });
    }).then(function () { root.__carnetPret = true; });
  }

  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', init); else init();
})(window);
