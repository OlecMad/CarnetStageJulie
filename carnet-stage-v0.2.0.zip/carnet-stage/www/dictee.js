/* Carnet de stage - dictée vocale.

   Correction des défauts relevés dans le plugin @capacitor-community/speech-recognition
   (SpeechRecognition.java, lu dans le paquet installé) tel qu'utilisé par DiagFluvial :

   1. Avec partialResults = true, le plugin répond tout de suite à start() ; onError() ne
      transmet donc plus aucune erreur au JavaScript. Une erreur (moteur occupé, aucune
      parole, réseau) laissait le bouton « en écoute » sans texte et sans message.
      -> Ici : un contrôle périodique (isListening) détecte le moteur arrêté sans signal,
         relance, et après 3 essais sans texte affiche une cause à l'écran.
   2. A l'arrêt, DiagFluvial retirait ses écouteurs aussitôt : le résultat final, qui
      arrive APRÈS stop(), était jeté. -> Ici : les écouteurs restent actifs 3 s après stop.
   3. onEndOfSpeech émet « stopped » AVANT le résultat final ; relancer tout de suite
      (cancel + destroy dans le plugin) pouvait supprimer ce résultat.
      -> Ici : relance seulement 1,2 s après le dernier texte reçu.
   4. Le texte d'un segment REMPLACE le segment précédent (il ne s'y ajoute jamais), ce qui
      évite les doublons quand un résultat partiel puis final arrivent pour la même phrase.

   Chaque événement est inscrit dans un journal consultable (Réglages > Diagnostic). */
(function (root) {
  'use strict';

  var LANG = 'fr-FR';
  var SETTLE_MS = 1200;     // attente du résultat final avant relance
  var FINISH_MS = 3000;     // écouteurs gardés après l'arrêt demandé
  var POLL_MS = 2000;       // contrôle du moteur
  var GRACE_MS = 2500;      // délai laissé au moteur pour passer en écoute
  var MAX_FAILS = 3;        // essais consécutifs sans texte avant message d'erreur

  var D = {
    want: false, on: false, stopping: false, ta: null, hooks: {}, P: null, web: null,
    base: '', seg: '', ended: false, launchAt: 0, got: false, fails: 0,
    poll: null, settle: null, fin: null, log: [], onLog: null
  };

  function stamp() { var d = new Date(); return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2) + ':' + ('0' + d.getSeconds()).slice(-2); }
  function log(m) { D.log.push(stamp() + '  ' + m); if (D.log.length > 80) D.log.shift(); if (D.onLog) D.onLog(D.log); }
  function msgOf(e) { return (e && (e.message || e.errorMessage || e.code)) ? String(e.message || e.errorMessage || e.code) : String(e || 'erreur inconnue'); }
  function say(m, isErr) { if (D.hooks.onMessage) D.hooks.onMessage(m, !!isErr); }
  function setValue(v) { D.ta.value = v; if (D.hooks.onText) D.hooks.onText(v); }
  function baseFrom(v) { v = String(v || '').replace(/\s+$/, ''); return v ? v + ' ' : ''; }

  function clearTimers() {
    if (D.poll) { clearInterval(D.poll); D.poll = null; }
    if (D.settle) { clearTimeout(D.settle); D.settle = null; }
  }

  function finalize() {
    if (D.fin) { clearTimeout(D.fin); D.fin = null; }
    clearTimers();
    var P = D.P;
    D.on = false; D.stopping = false; D.want = false;
    if (P && P.removeAllListeners) { try { P.removeAllListeners().catch(function () {}); } catch (e) { /* sans effet */ } }
    if (D.web) { try { D.web.onend = null; D.web.stop(); } catch (e) { /* sans effet */ } D.web = null; }
    log('dictée terminée');
    if (D.hooks.onDone && D.ta) D.hooks.onDone(D.ta.value);
  }

  function fail(message) {
    log('ECHEC : ' + message);
    stopRequest(true);
    say(message, true);
  }

  function stopRequest(immediate) {
    if (!D.on) return;
    D.want = false; D.stopping = true;
    clearTimers();
    if (D.hooks.onState) D.hooks.onState(false);
    if (D.P) { try { D.P.stop().catch(function () {}); } catch (e) { /* sans effet */ } }
    log('arrêt demandé' + (immediate ? '' : ', attente du dernier résultat (3 s)'));
    if (immediate) finalize(); else D.fin = setTimeout(finalize, FINISH_MS);
  }

  /* ---------- reconnaissance native (plugin) ---------- */
  function listen() {
    D.launchAt = Date.now(); D.got = false; D.ended = false; D.seg = '';
    log('lancement de l\'écoute');
    return D.P.start({ language: LANG, maxResults: 1, partialResults: true, popup: false })
      .then(function () { log('moteur démarré'); })
      .catch(function (e) { fail('Le moteur de dictée a refusé de démarrer : ' + msgOf(e)); });
  }

  function scheduleRelaunch() {
    if (D.settle) clearTimeout(D.settle);
    D.settle = setTimeout(relaunch, SETTLE_MS);
  }

  function relaunch() {
    D.settle = null;
    if (!D.want) return;
    if (!D.got) {
      D.fails++;
      log('aucun texte pour cet essai (' + D.fails + '/' + MAX_FAILS + ')');
      if (D.fails >= MAX_FAILS) {
        fail('Aucun texte reçu après ' + MAX_FAILS + ' essais. Causes possibles : parole non détectée, micro utilisé par une autre application, moteur de reconnaissance absent ou sans réseau (pack hors ligne non installé). Voir Réglages > Diagnostic.');
        return;
      }
    }
    D.base = baseFrom(D.ta.value);
    listen();
  }

  function onPartial(d) {
    if (!D.on && !D.stopping) return;
    var t = d && d.matches && d.matches.length ? String(d.matches[0] || '') : '';
    if (!t) return;
    D.seg = t; D.got = true; D.fails = 0;
    setValue(D.base + t);
    log('texte reçu (' + t.length + ' caractères)');
    if (D.ended && D.want) scheduleRelaunch();
  }

  function onState(d) {
    var s = d && d.status;
    log('état du moteur : ' + s);
    if (s === 'stopped') { D.ended = true; if (D.want) scheduleRelaunch(); }
    else if (s === 'started') { D.ended = false; }
  }

  function startNative(P) {
    D.P = P;
    return P.requestPermissions()
      .then(function (st) {
        if (st && st.speechRecognition && st.speechRecognition !== 'granted') {
          throw new Error('Permission du micro refusée. L\'accorder dans Paramètres > Applications > Carnet de stage > Autorisations.');
        }
        return P.available();
      })
      .then(function (a) {
        if (!a || !a.available) {
          if (D.hooks.onUnavailable) D.hooks.onUnavailable();
          throw new Error('Aucun service de reconnaissance vocale n\'est installé sur cet appareil. Essayer la dictée par fenêtre système, ou le micro du clavier.');
        }
        return Promise.all([
          P.addListener('partialResults', onPartial),
          P.addListener('listeningState', onState)
        ]);
      })
      .then(function () {
        D.want = true; D.on = true; D.stopping = false; D.fails = 0;
        D.base = baseFrom(D.ta.value);
        if (D.hooks.onState) D.hooks.onState(true);
        D.poll = setInterval(function () {
          if (!D.want || D.stopping || D.ended) return;
          if (Date.now() - D.launchAt < GRACE_MS) return;
          P.isListening().then(function (r) {
            if (D.want && !D.ended && r && r.listening === false) {
              log('moteur arrêté sans signal (erreur non transmise par le plugin)');
              D.ended = true; scheduleRelaunch();
            }
          }).catch(function () { /* contrôle sans effet */ });
        }, POLL_MS);
        return listen();
      });
  }

  /* ---------- repli navigateur (tests hors APK) ---------- */
  function startWeb() {
    var SR = root.SpeechRecognition || root.webkitSpeechRecognition;
    if (!SR) return Promise.reject(new Error('La dictée n\'est pas disponible dans ce navigateur.'));
    var r = new SR();
    r.lang = LANG; r.continuous = true; r.interimResults = true;
    D.web = r; D.want = true; D.on = true; D.base = baseFrom(D.ta.value);
    r.onresult = function (ev) {
      var fin = '', itm = '';
      for (var i = ev.resultIndex; i < ev.results.length; i++) {
        var tr = ev.results[i][0].transcript;
        if (ev.results[i].isFinal) fin += tr; else itm += tr;
      }
      if (fin) D.base += fin + ' ';
      setValue(D.base + itm);
    };
    r.onerror = function (ev) { log('erreur : ' + (ev && ev.error)); say('Erreur de dictée : ' + (ev && ev.error), true); };
    r.onend = function () { if (D.on) finalize(); };
    if (D.hooks.onState) D.hooks.onState(true);
    r.start();
    return Promise.resolve();
  }

  /* ---------- API ---------- */
  function demarrer(ta, hooks) {
    if (D.on || D.stopping) { stopRequest(false); return Promise.resolve(); }
    D.ta = ta; D.hooks = hooks || {};
    // iPhone (version web) : la reconnaissance vocale web n'est pas disponible dans une web app de
    // l'ecran d'accueil (rapport WebKit 225298). On amene le curseur dans la note : la dictée se fait
    // avec le micro du clavier iOS, le texte etant alors saisi comme au clavier.
    if (root.HW && root.HW.IOS && !root.HW.NATIVE) {
      log('iPhone : dictée par le micro du clavier');
      try { ta.focus(); } catch (e) { /* sans effet */ }
      say('Touche le micro en bas à droite du clavier iPhone pour dicter. Le texte arrive dans la note.', false);
      return Promise.resolve();
    }
    var P = root.HW && root.HW.NATIVE ? root.HW.plug('SpeechRecognition') : null;
    var p = P ? startNative(P) : (root.HW && root.HW.NATIVE ? Promise.reject(new Error('Plugin de reconnaissance vocale absent de cette version.')) : startWeb());
    return p.catch(function (e) {
      log('ECHEC : ' + msgOf(e));
      D.on = false; D.want = false; D.stopping = false; clearTimers();
      if (D.hooks.onState) D.hooks.onState(false);
      say(msgOf(e), true);
    });
  }

  function arreter() { stopRequest(false); }
  function actif() { return D.on || D.stopping; }

  /* Dictée par la fenêtre système (Android) : renvoie le texte complet en une fois. */
  function popup(ta, hooks) {
    var P = root.HW && root.HW.NATIVE ? root.HW.plug('SpeechRecognition') : null;
    D.hooks = hooks || {};
    if (!P) { say('Fenêtre de dictée indisponible dans cette version.', true); return Promise.resolve(); }
    log('dictée par fenêtre système');
    return P.requestPermissions()
      .then(function () { return P.start({ language: LANG, maxResults: 1, popup: true, prompt: 'Dictez votre note' }); })
      .then(function (r) {
        var t = r && r.matches && r.matches[0] ? String(r.matches[0]) : '';
        if (!t) { log('fenêtre système : aucun texte'); say('Aucun texte reçu de la fenêtre système.', true); return; }
        ta.value = baseFrom(ta.value) + t;
        log('fenêtre système : ' + t.length + ' caractères');
        if (D.hooks.onText) D.hooks.onText(ta.value);
        if (D.hooks.onDone) D.hooks.onDone(ta.value);
      })
      .catch(function (e) {
        var m = msgOf(e);
        log('fenêtre système : ' + m);
        say(m === '0' ? 'Dictée annulée.' : 'La fenêtre de dictée a échoué : ' + m, true);
      });
  }

  /* Etat de l'appareil pour le diagnostic. */
  function etat() {
    var o = { native: !!(root.HW && root.HW.NATIVE), plugin: false, permission: 'inconnue', disponible: null, erreur: null };
    var P = o.native ? root.HW.plug('SpeechRecognition') : null;
    if (!P) return Promise.resolve(o);
    o.plugin = true;
    return P.checkPermissions().then(function (s) { o.permission = s && s.speechRecognition; }).catch(function (e) { o.erreur = msgOf(e); })
      .then(function () { return P.available(); })
      .then(function (a) { o.disponible = !!(a && a.available); })
      .catch(function (e) { o.erreur = msgOf(e); })
      .then(function () { return o; });
  }

  root.Dictee = {
    demarrer: demarrer, arreter: arreter, actif: actif, popup: popup, etat: etat,
    journal: function () { return D.log.slice(); },
    setOnLog: function (f) { D.onLog = f; },
    _interne: D
  };
})(typeof window !== 'undefined' ? window : globalThis);
