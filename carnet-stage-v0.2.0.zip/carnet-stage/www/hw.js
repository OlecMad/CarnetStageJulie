/* Carnet de stage - couche materielle.
   Dans l'APK : plugins Capacitor. Dans un navigateur : repli web (fichier, telechargement).
   Valeurs d'enumeration verifiees dans les paquets installes :
   Directory.Documents = 'DOCUMENTS', CameraResultType.DataUrl = 'dataUrl', CameraSource.Camera = 'CAMERA'. */
(function (root) {
  'use strict';
  var CAP = root.Capacitor || null;
  var NATIVE = !!(CAP && typeof CAP.isNativePlatform === 'function' && CAP.isNativePlatform());

  function plug(name) {
    if (!CAP || !CAP.Plugins) return null;
    if (typeof CAP.isPluginAvailable === 'function' && !CAP.isPluginAvailable(name)) return null;
    return CAP.Plugins[name] || null;
  }

  /* Photo : renvoie une dataUrl JPEG (largeur max 1280, qualite 72). */
  function takePhoto() {
    var C = NATIVE ? plug('Camera') : null;
    if (C) {
      return C.getPhoto({ quality: 72, width: 1280, allowEditing: false, correctOrientation: true, saveToGallery: false, resultType: 'dataUrl', source: 'CAMERA' })
        .then(function (p) { if (!p || !p.dataUrl) throw new Error('annule'); return p.dataUrl; });
    }
    return new Promise(function (res, rej) {
      var inp = root.document.getElementById('ph-fichier');
      inp.value = '';
      inp.onchange = function () {
        var f = inp.files && inp.files[0];
        if (!f) return rej(new Error('annule'));
        var r = new FileReader();
        r.onload = function () { res(String(r.result)); };
        r.onerror = function () { rej(r.error); };
        r.readAsDataURL(f);
      };
      inp.click();
    });
  }

  function blobToBase64(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result).split(',')[1] || ''); };
      r.onerror = function () { rej(r.error); };
      r.readAsDataURL(blob);
    });
  }

  function stamped(name) { return name.replace(/(\.[a-z0-9]+)$/i, '_' + new Date().toISOString().replace(/[-:]/g, '').slice(0, 15) + '$1'); }

  /* Ecrit dans Documents puis propose le partage. Renvoie le nom du fichier ecrit. */
  function nativeSave(filename, data, encoding, shareTitle) {
    var F = plug('Filesystem'), S = plug('Share');
    if (!F) return Promise.reject(new Error('Enregistrement indisponible'));
    function write(name) {
      var o = { path: name, data: data, directory: 'DOCUMENTS', recursive: true };
      if (encoding) o.encoding = encoding;
      return F.writeFile(o).then(function () { return name; });
    }
    // Android 11+ : un fichier laisse par une installation precedente peut etre non modifiable.
    return write(filename).catch(function () { return write(stamped(filename)); })
      .then(function (name) {
        filename = name;
        return F.getUri({ path: name, directory: 'DOCUMENTS' });
      })
      .then(function (r) {
        if (S && r && r.uri) { return S.share({ title: shareTitle || 'Carnet de stage', url: r.uri, dialogTitle: 'Partager' }).catch(function () { /* partage refuse : le fichier est ecrit */ }); }
      })
      .then(function () { return filename; });
  }

  function webDownload(filename, blob) {
    var a = root.document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = filename;
    root.document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    return Promise.resolve(filename);
  }

  /* Version web : sur iPhone, un telechargement par lien est peu fiable ; la feuille de partage
     (navigator.share avec fichier) permet d'enregistrer dans Fichiers, Mail, AirDrop. Elle exige un
     geste de l'utilisateur recent : le fichier etant genere apres le clic, on affiche un bouton. */
  function canShareFile(file) {
    try { return !!(root.navigator && navigator.share && navigator.canShare && navigator.canShare({ files: [file] })); } catch (e) { return false; }
  }
  function webSave(filename, blob, mime, ui) {
    var file;
    try { file = new root.File([blob], filename, { type: mime }); } catch (e) { file = null; }
    if (file && ui && canShareFile(file)) {
      return new Promise(function (res) {
        ui.innerHTML = '<div class="msg">Fichier prêt : ' + filename + '</div><div class="row"><button class="btn" id="partager-fichier">Enregistrer ou partager le fichier</button></div>';
        var b = ui.querySelector('#partager-fichier');
        b.onclick = function () {
          navigator.share({ files: [file], title: filename })
            .then(function () { res(filename + ' (partagé)'); })
            .catch(function (e) {
              if (e && e.name === 'AbortError') return; // feuille fermee : le bouton reste disponible
              webDownload(filename, blob).then(function () { res(filename); });
            });
        };
      });
    }
    return webDownload(filename, blob);
  }

  function saveBlob(filename, blob, title, ui) {
    if (NATIVE && plug('Filesystem')) return blobToBase64(blob).then(function (b64) { return nativeSave(filename, b64, null, title); });
    return webSave(filename, blob, blob.type || 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', ui);
  }
  function saveText(filename, text, title, ui) {
    if (NATIVE && plug('Filesystem')) return nativeSave(filename, text, 'utf8', title);
    return webSave(filename, new Blob([text], { type: 'application/json' }), 'application/json', ui);
  }
  var IOS = !!(root.navigator && (/iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)));

  root.HW = { IOS: IOS, NATIVE: NATIVE, plug: plug, takePhoto: takePhoto, saveBlob: saveBlob, saveText: saveText };
})(typeof window !== 'undefined' ? window : globalThis);
