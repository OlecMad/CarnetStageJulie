/* Carnet de stage - compilation du carnet en .docx (hors ligne, bibliothèque docx locale). */
(function (root) {
  'use strict';

  var FONT = 'Calibri';
  var GREEN = '1F5F3A', GREY = '5D6B61', LINE = 'D5DBD1';
  var MAXW = 560; // pixels, largeur utile de la page A4 avec marges de 2 cm

  function pl(n, w) { return n + ' ' + w + (n > 1 ? 's' : ''); }

  function b64ToBytes(b64) {
    var bin = root.atob(b64), n = bin.length, u = new Uint8Array(n);
    for (var i = 0; i < n; i++) u[i] = bin.charCodeAt(i);
    return u;
  }
  function dataUrlInfo(u) {
    var m = /^data:image\/(png|jpe?g|gif|bmp);base64,(.*)$/i.exec(u || '');
    if (!m) return null;
    var t = m[1].toLowerCase(); if (t === 'jpeg') t = 'jpg';
    return { type: t, data: b64ToBytes(m[2]) };
  }

  /* Dimensions : celles enregistrées, sinon lues dans l'image (navigateur). */
  function dims(item) {
    if (item.w && item.h) return Promise.resolve([item.w, item.h]);
    return new Promise(function (res) {
      if (!root.Image) return res([4, 3]);
      var im = new root.Image();
      im.onload = function () { res([im.naturalWidth || 4, im.naturalHeight || 3]); };
      im.onerror = function () { res([4, 3]); };
      im.src = item.data || item.png;
    });
  }

  function build(data, opts) {
    var X = root.docx;
    if (!X) return Promise.reject(new Error('Bibliothèque docx absente'));
    var S = root.Store;
    var du = opts.du || '0000-00-00', au = opts.au || '9999-99-99';
    function inRange(x) { return x.jour >= du && x.jour <= au; }
    var notes = data.notes.filter(inRange), photos = data.photos.filter(inRange), schemas = data.schemas.filter(inRange);
    var meta = data.stage || {};
    var joursStage = (data.joursStage || []).filter(function (j) { return j >= du && j <= au; }).sort();

    // Elements unifies, tries chronologiquement
    var items = [];
    notes.forEach(function (n) { items.push({ kind: 'note', jour: n.jour, t: n.creeLe, rub: n.rubrique, o: n }); });
    photos.forEach(function (p) { items.push({ kind: 'photo', jour: p.jour, t: p.creeLe, rub: p.rubrique, o: p }); });
    schemas.forEach(function (s) { items.push({ kind: 'schema', jour: s.jour, t: s.creeLe, rub: s.rubrique, o: s }); });
    items.sort(function (a, b) { return a.t < b.t ? -1 : a.t > b.t ? 1 : 0; });

    function P(text, o) {
      o = o || {};
      return new X.Paragraph({
        alignment: o.center ? X.AlignmentType.CENTER : undefined,
        spacing: { before: o.before || 0, after: o.after === undefined ? 100 : o.after }, keepNext: !!o.keepNext,
        children: [new X.TextRun({ text: text, bold: !!o.bold, italics: !!o.italic, color: o.color, size: o.size || 22, font: FONT })]
      });
    }
    function H(level, text) {
      return new X.Paragraph({
        heading: level === 1 ? X.HeadingLevel.HEADING_1 : level === 2 ? X.HeadingLevel.HEADING_2 : X.HeadingLevel.HEADING_3,
        keepNext: true, spacing: { before: level === 1 ? 360 : 220, after: 100 },
        children: [new X.TextRun({ text: text, bold: true, color: GREEN, size: level === 1 ? 32 : level === 2 ? 26 : 23, font: FONT })]
      });
    }
    function stamp(it) { return S.horodatageFr(new Date(it.t)); }

    var body = [];
    var border = { style: X.BorderStyle.SINGLE, size: 4, color: LINE };
    var borders = { top: border, bottom: border, left: border, right: border };
    function cell(t, w, head) {
      return new X.TableCell({
        width: { size: w, type: X.WidthType.DXA }, borders: borders, margins: { top: 60, bottom: 60, left: 90, right: 90 },
        shading: head ? { type: X.ShadingType.CLEAR, fill: 'E9F1E6', color: 'auto' } : undefined,
        children: [new X.Paragraph({ children: [new X.TextRun({ text: String(t), bold: !!head, size: 20, font: FONT })] })]
      });
    }
    function table(head, rows, ws) {
      var W = ws.reduce(function (a, b) { return a + b; }, 0);
      var trs = [new X.TableRow({ tableHeader: true, cantSplit: true, children: head.map(function (h, i) { return cell(h, ws[i], true); }) })];
      rows.forEach(function (r) { trs.push(new X.TableRow({ cantSplit: true, children: r.map(function (v, i) { return cell(v, ws[i], false); }) })); });
      return new X.Table({ width: { size: W, type: X.WidthType.DXA }, columnWidths: ws, rows: trs });
    }

    // ---- Page de titre et fiche de stage
    var PR = root.Profil || { titre: 'Carnet de stage', sousTitre: '' };
    body.push(P(PR.titre, { bold: true, size: 56, color: GREEN, before: 1200, after: 60 }));
    body.push(P(PR.sousTitre, { size: 28, color: GREY, after: 360 }));
    var fiche = [
      ['Étudiant', meta.nom || ''], ['Exploitation', meta.expl || ''], ['Lieu', meta.lieu || ''], ['Maître de stage', meta.maitre || ''],
      ['Période du carnet', S.dateFr(du === '0000-00-00' ? (items[0] ? items[0].jour : S.jourLocal()) : du) + ' au ' + S.dateFr(au === '9999-99-99' ? (items.length ? items[items.length - 1].jour : S.jourLocal()) : au)],
      ['Jours de stage notés', joursStage.length + (meta.obj ? ' sur ' + meta.obj : '')],
      ['Contenu', pl(notes.length, 'note') + ', ' + pl(photos.length, 'photo') + ', ' + pl(schemas.length, 'schéma')],
      ['Édité le', S.horodatageFr(new Date())]
    ];
    body.push(table(['Rubrique', 'Valeur'], fiche, [2800, 6200]));

    if (joursStage.length) {
      body.push(H(2, 'Jours de stage'));
      body.push(P(joursStage.map(S.dateFr).join(', ') + '.', { size: 20 }));
    }

    // ---- Corps
    var tasks = [];
    function sectionItems(list) {
      list.forEach(function (it) {
        tasks.push(function () { return renderItem(it); });
      });
    }
    function renderItem(it) {
      var out = [];
      var rubTxt = it.rub ? ' - ' + it.rub : '';
      if (it.kind === 'note') {
        out.push(new X.Paragraph({ keepNext: true, spacing: { before: 160, after: 40 }, children: [
          new X.TextRun({ text: 'Note du ' + stamp(it), bold: true, size: 22, color: GREEN, font: FONT }),
          new X.TextRun({ text: opts.org === 'jour' ? rubTxt : '', size: 20, color: GREY, font: FONT })] }));
        String(it.o.texte || '').split(/\n+/).forEach(function (l) { if (l.trim()) out.push(P(l.trim())); });
        return Promise.resolve(out);
      }
      var img = it.kind === 'photo' ? it.o.data : it.o.png;
      var info = dataUrlInfo(img);
      if (!info) { out.push(P('[image illisible]', { italic: true, color: GREY })); return Promise.resolve(out); }
      return dims(it.kind === 'photo' ? { w: it.o.w, h: it.o.h, data: img } : { w: it.o.w, h: it.o.h, png: img }).then(function (d) {
        var k = Math.min(1, MAXW / d[0], 520 / d[1]);
        var cap = (it.kind === 'photo' ? 'Photo du ' : 'Schéma du ') + stamp(it) +
          (it.kind === 'schema' && it.o.titre ? ' - ' + it.o.titre : '') + (it.kind === 'photo' && it.o.legende ? ' - ' + it.o.legende : '') +
          (opts.org === 'jour' ? rubTxt : '');
        out.push(new X.Paragraph({ keepNext: true, spacing: { before: 160, after: 60 }, alignment: X.AlignmentType.CENTER, children: [
          new X.ImageRun({ type: info.type, data: info.data, transformation: { width: Math.max(1, Math.round(d[0] * k)), height: Math.max(1, Math.round(d[1] * k)) } })] }));
        out.push(P(cap, { italic: true, color: GREY, size: 19, center: true }));
        return out;
      });
    }

    if (opts.org === 'jour') {
      var jours = {};
      items.forEach(function (it) { (jours[it.jour] = jours[it.jour] || []).push(it); });
      Object.keys(jours).sort().forEach(function (j) {
        var marker = joursStage.indexOf(j) >= 0 ? ' (jour de stage)' : '';
        tasks.push(function () { return Promise.resolve([H(1, S.dateFr(j) + marker)]); });
        sectionItems(jours[j]);
      });
    } else {
      var ordre = S.RUBRIQUES.slice();
      items.forEach(function (it) { var r = it.rub || 'Libre'; if (ordre.indexOf(r) < 0) ordre.push(r); });
      ordre.forEach(function (r) {
        var l = items.filter(function (it) { return (it.rub || 'Libre') === r; });
        if (!l.length) return;
        tasks.push(function () { return Promise.resolve([H(1, r)]); });
        sectionItems(l);
      });
    }
    if (!items.length) body.push(P('Aucun élément sur la période choisie.', { italic: true, color: GREY, before: 240 }));

    // Execution sequentielle (ordre conserve)
    var chain = Promise.resolve();
    tasks.forEach(function (t) { chain = chain.then(t).then(function (els) { els.forEach(function (e) { body.push(e); }); }); });

    return chain.then(function () {
      var foot = new X.Footer({ children: [new X.Paragraph({ alignment: X.AlignmentType.RIGHT, children: [
        new X.TextRun({ text: 'Carnet de stage - page ', color: GREY, size: 16, font: FONT }),
        new X.TextRun({ children: [X.PageNumber.CURRENT], color: GREY, size: 16, font: FONT })] })] });
      return new X.Document({
        creator: 'Carnet de stage', title: 'Carnet de stage',
        styles: {
          default: { document: { run: { font: FONT, size: 22 } } },
          // styles de titres declares : volet de navigation de Word et table des matieres
          paragraphStyles: [
            { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FONT, size: 32, bold: true, color: GREEN }, paragraph: { spacing: { before: 360, after: 100 }, outlineLevel: 0 } },
            { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FONT, size: 26, bold: true, color: GREEN }, paragraph: { spacing: { before: 220, after: 100 }, outlineLevel: 1 } },
            { id: 'Heading3', name: 'Heading 3', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FONT, size: 23, bold: true, color: GREEN }, paragraph: { spacing: { before: 220, after: 100 }, outlineLevel: 2 } }
          ]
        },
        sections: [{
          properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1134, bottom: 1134, left: 1134, right: 1134 } } },
          footers: { default: foot },
          children: body
        }]
      });
    });
  }

  function toBlob(doc) { return root.docx.Packer.toBlob(doc); }

  /* Compte pour l'ecran d'export. */
  function resume(data, du, au) {
    function inr(x) { return x.jour >= (du || '0000-00-00') && x.jour <= (au || '9999-99-99'); }
    return { notes: data.notes.filter(inr).length, photos: data.photos.filter(inr).length, schemas: data.schemas.filter(inr).length };
  }

  root.Export = { build: build, toBlob: toBlob, resume: resume };
})(typeof window !== 'undefined' ? window : globalThis);
