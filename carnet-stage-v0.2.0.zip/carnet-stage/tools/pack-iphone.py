#!/usr/bin/env python3
"""Assemble la version web (iPhone) d'un profil : python3 tools/pack-iphone.py julie-mvaoe [sortie.zip]"""
import sys, os, json, zipfile, re
racine = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
nom = sys.argv[1]; sortie = sys.argv[2] if len(sys.argv) > 2 else nom + '-iphone.zip'
www = os.path.join(racine, 'www')
profil = open(os.path.join(racine, 'profils', nom + '.js'), encoding='utf-8').read()
sw = open(os.path.join(www, 'sw.js'), encoding='utf-8').read().replace("'carnet-v", "'carnet-" + nom + "-v")
man = json.load(open(os.path.join(www, 'manifest.json'), encoding='utf-8'))
with zipfile.ZipFile(sortie, 'w', zipfile.ZIP_DEFLATED) as z:
    for d, _, fs in os.walk(www):
        for f in fs:
            full = os.path.join(d, f); rel = os.path.relpath(full, www)
            if f == '.DS_Store': continue
            if rel == 'profil.js': z.writestr(rel, profil)
            elif rel == 'sw.js': z.writestr(rel, sw)
            else: z.write(full, rel)
print('ecrit', sortie)
