/* Tests du carnet de stage (jsdom + fake-indexeddb + plugin Capacitor simulé).
   Usage : node tools/test-carnet.js   (dépendances : jsdom, fake-indexeddb) */
const { JSDOM } = require('jsdom');
const { IDBFactory, IDBKeyRange } = require('fake-indexeddb');
const fs = require('fs'), path = require('path');
const WWW = path.join(__dirname, '..', 'www');
const OUTDOCX = process.env.OUTDOCX || '/tmp/carnet-test.docx';

let ok = 0, ko = 0;
function check(c, m) { if (c) { ok++; console.log('  ok   ' + m); } else { ko++; console.log('  ECHEC ' + m); } }

// PNG 1x1
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
const JPG_FAKE = PNG.replace('image/png', 'image/png');

function makeClock() {
  const c = { now: 1700000000000, timers: [], id: 1 };
  c.set = (fn, ms) => { const t = { id: c.id++, at: c.now + (ms || 0), fn, every: 0 }; c.timers.push(t); return t.id; };
  c.setI = (fn, ms) => { const t = { id: c.id++, at: c.now + ms, fn, every: ms }; c.timers.push(t); return t.id; };
  c.clear = (id) => { c.timers = c.timers.filter((t) => t.id !== id); };
  c.advance = async (ms) => {
    const end = c.now + ms;
    for (;;) {
      c.timers.sort((a, b) => a.at - b.at);
      const t = c.timers[0];
      if (!t || t.at > end) break;
      c.now = t.at;
      if (t.every) t.at += t.every; else c.timers.shift();
      t.fn();
      await Promise.resolve(); await Promise.resolve();
    }
    c.now = end;
    await new Promise((r) => setImmediate(r));
  };
  return c;
}

function fakeSpeech(state) {
  const L = {};
  const P = {
    calls: { start: 0, stop: 0, remove: 0, popup: 0 },
    async requestPermissions() { return { speechRecognition: state.perm || 'granted' }; },
    async checkPermissions() { return { speechRecognition: state.perm || 'granted' }; },
    async available() { return { available: state.available !== false }; },
    async start(o) {
      if (o.popup) { P.calls.popup++; if (state.popupFail) throw new Error('0'); return { matches: ['texte de la fenetre'] }; }
      P.calls.start++;
      if (state.startFail) throw new Error('Missing permission');
      state.listening = true; state.launched = state.clock.now; return {};
    },
    async stop() { P.calls.stop++; state.listening = false; },
    async isListening() { return { listening: !!state.listening }; },
    async addListener(n, f) { L[n] = f; return { remove() {} }; },
    async removeAllListeners() { P.calls.remove++; delete L.partialResults; delete L.listeningState; },
    emit(n, d) { if (L[n]) L[n](d); },
    hasListener(n) { return !!L[n]; }
  };
  return P;
}

async function boot(mode, state) {
  const clock = makeClock(); state.clock = clock;
  const files = {};
  const speech = fakeSpeech(state);
  const dom = await JSDOM.fromFile(path.join(WWW, 'index.html'), {
    runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true,
    beforeParse(w) {
      w.indexedDB = new IDBFactory(); w.IDBKeyRange = IDBKeyRange;
      w.TextEncoder = TextEncoder; w.TextDecoder = TextDecoder; // présents dans une vraie WebView
      w.setImmediate = setImmediate; w.clearImmediate = clearImmediate; // le polyfill postMessage de JSZip ne fonctionne pas dans jsdom
      w.setTimeout = clock.set; w.setInterval = clock.setI; w.clearTimeout = clock.clear; w.clearInterval = clock.clear;
      w.Date.now = () => clock.now;
      // canvas minimal
      const ctx = new Proxy({}, { get: (t, k) => (k === 'measureText' ? () => ({ width: 100 }) : typeof t[k] !== 'undefined' ? t[k] : () => {}), set: (t, k, v) => { t[k] = v; return true; } });
      w.HTMLCanvasElement.prototype.getContext = () => ctx;
      w.HTMLCanvasElement.prototype.toDataURL = () => PNG;
      w.Image = function () { const o = {}; setImmediate(() => { o.naturalWidth = 640; o.naturalHeight = 480; if (o.onload) o.onload(); }); return o; };
      w.HTMLCanvasElement.prototype.setPointerCapture = () => {};
      w.Element.prototype.setPointerCapture = () => {};
      if (mode === 'native') {
        w.Capacitor = {
          isNativePlatform: () => true, isPluginAvailable: () => true,
          Plugins: {
            SpeechRecognition: speech,
            Camera: { getPhoto: async () => ({ dataUrl: PNG }) },
            Filesystem: { writeFile: async (o) => { files[o.path] = o; return { uri: 'file://' + o.path }; }, getUri: async (o) => ({ uri: 'file:///Documents/' + o.path }) },
            Share: { share: async () => ({}) }
          }
        };
      }
    }
  });
  const w = dom.window;
  await new Promise((r) => { const iv = setInterval(() => { if (w.__carnetPret) { clearInterval(iv); r(); } }, 20); });
  return { dom, w, clock, speech, files, $: (id) => w.document.getElementById(id) };
}
const tick = () => new Promise((r) => setImmediate(r));
async function until(f, n = 100) { for (let i = 0; i < n; i++) { if (f()) return true; await new Promise((r) => setTimeout(r, 10)); } return false; }

(async () => {
  /* ===== 1. Dictée, scénarios ===== */
  console.log('1. Dictée native (plugin simulé)');
  {
    const st = {}; const t = await boot('native', st); const { w, clock, speech, $ } = t;
    const ta = $('n-texte');
    $('n-mic').click(); await until(() => speech.calls.start === 1);
    check(speech.calls.start === 1 && speech.hasListener('partialResults'), 'démarrage : écoute lancée, écouteurs posés');
    check($('n-mic').textContent.includes('Arrêter'), 'bouton passe en mode arrêt');
    speech.emit('partialResults', { matches: ['bonjour'] });
    speech.emit('partialResults', { matches: ['bonjour le stage'] });
    check(ta.value === 'bonjour le stage', 'texte partiel affiché dans la note : « ' + ta.value + ' »');
    // fin de parole, résultat final 300 ms après, relance seulement après 1,2 s
    speech.emit('listeningState', { status: 'stopped' }); st.listening = false;
    await clock.advance(300);
    speech.emit('partialResults', { matches: ['bonjour le stage commence demain'] });
    await clock.advance(900);
    check(speech.calls.start === 1, 'pas de relance avant 1,2 s (le résultat final n\'est pas écrasé)');
    check(ta.value === 'bonjour le stage commence demain', 'résultat final reçu après la fin de parole conservé');
    await clock.advance(600); await tick();
    check(speech.calls.start === 2, 'relance après le délai de stabilisation');
    speech.emit('partialResults', { matches: ['ensuite'] });
    check(ta.value === 'bonjour le stage commence demain ensuite', 'segment suivant ajouté sans doublon : « ' + ta.value + ' »');
    // arrêt : le résultat final arrive APRÈS stop() (cas perdu dans DiagFluvial)
    $('n-mic').click(); await tick();
    check(speech.calls.stop === 1, 'stop() envoyé');
    check(speech.hasListener('partialResults'), 'écouteurs encore actifs juste après l\'arrêt');
    await clock.advance(800);
    speech.emit('partialResults', { matches: ['ensuite et la fin'] });
    check(ta.value === 'bonjour le stage commence demain ensuite et la fin', 'résultat final arrivé après l\'arrêt conservé : « ' + ta.value + ' »');
    await clock.advance(3200);
    check(speech.calls.remove === 1 && !speech.hasListener('partialResults'), 'écouteurs retirés 3 s après l\'arrêt');
    check($('n-mic').textContent === 'Dicter', 'bouton revenu à « Dicter »');
    $('n-save').click(); await until(() => w.document.querySelectorAll('#n-liste .card').length === 1);
    check(w.document.querySelectorAll('#n-liste .card').length === 1, 'note dictée enregistrée dans le journal');
    check(ta.value === '', 'zone de saisie vidée après enregistrement');
  }
  {
    console.log('2. Erreur silencieuse du moteur (cas non signalé par le plugin)');
    const st = {}; const t = await boot('native', st); const { clock, speech, $ } = t;
    $('n-mic').click(); await until(() => speech.calls.start === 1);
    // le moteur s'arrête seul : listening=false, aucun événement
    st.listening = false;
    for (let i = 0; i < 12 && speech.calls.start < 3; i++) await clock.advance(2000);
    check(speech.calls.start >= 2, 'relance automatique après arrêt silencieux (démarrages : ' + speech.calls.start + ')');
    for (let i = 0; i < 20; i++) { st.listening = false; await clock.advance(2000); }
    const m = $('n-msg').textContent;
    check(/Aucun texte reçu après 3 essais/.test(m), 'message d\'échec visible : « ' + m.slice(0, 60) + '… »');
    check($('n-mic').textContent === 'Dicter', 'bouton remis à « Dicter » (plus de rouge sans écoute)');
    check(t.w.Dictee.journal().some((l) => /moteur arrêté sans signal/.test(l)), 'journal de diagnostic renseigné');
  }
  {
    console.log('3. Moteur absent, permission refusée, démarrage refusé');
    let st = { available: false }; let t = await boot('native', st);
    t.$('n-mic').click(); await until(() => /Aucun service de reconnaissance/.test(t.$('n-msg').textContent));
    check(/Aucun service de reconnaissance/.test(t.$('n-msg').textContent), 'moteur absent : message explicite');
    check(!t.$('n-popup').hidden, 'bouton « fenêtre système » proposé');
    st = { perm: 'denied' }; t = await boot('native', st);
    t.$('n-mic').click(); await until(() => /Permission du micro refusée/.test(t.$('n-msg').textContent));
    check(/Permission du micro refusée/.test(t.$('n-msg').textContent), 'permission refusée : message avec chemin des réglages');
    st = { startFail: true }; t = await boot('native', st);
    t.$('n-mic').click(); await until(() => /refusé de démarrer/.test(t.$('n-msg').textContent));
    check(/refusé de démarrer : Missing permission/.test(t.$('n-msg').textContent), 'start() rejeté : cause affichée (avant : avalée)');
    st = {}; t = await boot('native', st);
    t.$('n-popup').click(); await until(() => t.$('n-texte').value.length > 0);
    check(t.$('n-texte').value === 'texte de la fenetre', 'dictée par fenêtre système : texte inséré');
    st = { popupFail: true }; t = await boot('native', st);
    t.$('n-popup').click(); await until(() => /annulée/.test(t.$('n-msg').textContent));
    check(/annulée/.test(t.$('n-msg').textContent), 'fenêtre système annulée : message');
  }
  {
    console.log('4. Diagnostic');
    const st = {}; const t = await boot('native', st);
    t.$('d-etat').click(); await until(() => /Moteur de reconnaissance présent/.test(t.$('d-etat-res').textContent));
    check(/Application Android/.test(t.$('d-etat-res').textContent) && /Micro : granted/.test(t.$('d-etat-res').textContent), 'état : plateforme et micro');
    check(/Moteur de reconnaissance présent/.test(t.$('d-etat-res').textContent), 'état : moteur présent');
  }

  /* ===== 5. Notes, photos, schémas, export ===== */
  console.log('5. Notes, photos, schémas');
  const st = {}; const t = await boot('native', st); const { w, clock, speech, files, $ } = t;
  $('n-rub').value = 'QHSE (E6, fiche 3)'; $('n-texte').value = 'Nettoyage de la salle de traite après chaque traite.\nRegistre signé.';
  $('n-save').click(); await until(() => w.document.querySelectorAll('#n-liste .card').length === 1);
  if (process.env.DBG) console.log('   notes en base :', (await w.Store.all('notes')).map((n) => n.jour + ' ' + n.texte.slice(0, 20)));
  check(w.document.querySelectorAll('#n-liste .card').length === 1, 'note enregistrée (rubrique QHSE)');
  $('n-texte').value = 'Composition du troupeau : 62 vaches.'; $('n-rub').value = 'Combinaison productive (E6, fiche 1)'; $('n-save').click();
  await until(() => w.document.querySelectorAll('#n-liste .card').length === 2);
  $('j-stage').click(); await tick(); await tick();
  check(/Jours : 1 \/ 40/.test($('compteur').textContent), 'compteur de jours de stage : ' + $('compteur').textContent);
  $('ph-rub').value = 'QHSE (E6, fiche 3)'; $('ph-leg').value = 'Registre de nettoyage';
  $('ph-take').click(); await until(() => w.document.querySelectorAll('#ph-liste .card').length === 1);
  check(w.document.querySelectorAll('#ph-liste .card').length === 1, 'photo enregistrée');
  const photos = await w.Store.all('photos');
  check(photos.length === 1 && /^\d{4}-\d\d-\d\dT/.test(photos[0].creeLe) && photos[0].jour === w.Store.jourLocal(new w.Date(photos[0].creeLe)), 'photo horodatée : ' + photos[0].creeLe + ' (jour ' + photos[0].jour + ')');
  // schéma
  const cv = $('canvas');
  cv.getBoundingClientRect = () => ({ left: 0, top: 0, width: 600, height: 400 });
  function ptr(type, x, y) { const e = new w.MouseEvent(type, { clientX: x, clientY: y, bubbles: true }); e.pointerId = 1; cv.dispatchEvent(e); }
  const ed = () => w.SchemaEditor;
  for (const [tool, pts] of [['pen', [[10, 10], [50, 60], [90, 20]]], ['rect', [[100, 100], [200, 180]]], ['ellipse', [[220, 100], [320, 180]]], ['line', [[10, 300], [300, 300]]]]) {
    [].forEach.call(w.document.querySelectorAll('#s-outils button'), (b) => { if (b.dataset.tool === tool) b.click(); });
    ptr('pointerdown', ...pts[0]); for (const p of pts.slice(1)) ptr('pointermove', ...p); ptr('pointerup', ...pts[pts.length - 1]);
  }
  [].forEach.call(w.document.querySelectorAll('#s-outils button'), (b) => { if (b.dataset.tool === 'text') b.click(); });
  $('s-texte').value = 'Salle de traite'; $('s-poser').click(); ptr('pointerdown', 120, 250);
  $('s-titre').value = 'Plan des bâtiments'; $('s-rub').value = 'Combinaison productive (E6, fiche 1)';
  $('s-undo').click(); $('s-redo').click();
  $('s-save').click(); await until(() => w.document.querySelectorAll('#s-liste .card').length === 1);
  const sch = await w.Store.all('schemas');
  check(sch.length === 1 && sch[0].traits.length === 5 && /^data:image\/png/.test(sch[0].png), 'schéma enregistré : ' + (sch[0] && sch[0].traits.map((x) => x.t).join(',')));
  // gomme : efface le rectangle
  [].forEach.call(w.document.querySelectorAll('#s-outils button'), (b) => { if (b.dataset.tool === 'erase') b.click(); });
  w.document.querySelector('#s-liste .card .btn.sec').click(); // Rouvrir
  await tick();
  ptr('pointerdown', 100, 100); ptr('pointerup', 100, 100);
  check(w.Store && true, 'gomme sur un tracé exécutée sans erreur');

  console.log('5b. Annotation d\'une photo');
  {
    const btn = [].find.call(w.document.querySelectorAll('#ph-liste .card .btn.sec'), (b) => /Annoter/.test(b.textContent));
    check(!!btn, 'bouton « Annoter » sur la carte photo');
    btn.click(); await until(() => !$('s-annot').hidden);
    check(!$('p-schema').hidden && !$('s-annot').hidden && $('s-meta').hidden, 'éditeur ouvert en mode annotation (titre et rubrique masqués)');
    check(cv.width === 640 && cv.height === 480, 'canevas aux dimensions de la photo : ' + cv.width + 'x' + cv.height);
    for (const [tool, pts] of [['pen', [[20, 20], [80, 90], [150, 40]]], ['ellipse', [[200, 100], [300, 180]]]]) {
      [].forEach.call(w.document.querySelectorAll('#s-outils button'), (b) => { if (b.dataset.tool === tool) b.click(); });
      ptr('pointerdown', ...pts[0]); for (const p of pts.slice(1)) ptr('pointermove', ...p); ptr('pointerup', ...pts[pts.length - 1]);
    }
    $('s-save').click(); await until(() => w.document.querySelector('#ph-liste .card') && /Modifier l.annotation/.test(w.document.querySelector('#ph-liste .card').textContent));
    const ph = (await w.Store.all('photos'))[0];
    check(ph.annote === true && ph.traits.length === 2 && !!ph.orig && /^data:image\//.test(ph.data), 'photo annotée enregistrée : ' + ph.traits.map((x) => x.t).join(',') + ', original conservé');
    check($('s-annot').hidden && !$('s-meta').hidden && cv.width === 1200, 'retour à l\'éditeur de schémas normal');
    // réédition puis retrait des annotations
    w.document.querySelector('#ph-liste .card .btn.sec').click(); await until(() => !$('s-annot').hidden);
    check(true, 'annotation rouverte');
    $('s-clear').click(); $('s-save').click(); await until(() => /Annoter$/.test(w.document.querySelector('#ph-liste .card .btn.sec').textContent));
    const ph2 = (await w.Store.all('photos'))[0];
    check(ph2.annote === false && ph2.data === ph2.orig, 'annotations retirées : photo d\'origine restaurée');
    w.document.querySelector('#ph-liste .card .btn.sec').click(); await until(() => !$('s-annot').hidden);
    ptr('pointerdown', 50, 50); ptr('pointermove', 90, 90); ptr('pointerup', 90, 90);
    $('s-save').click(); await until(() => /Modifier l.annotation/.test(w.document.querySelector('#ph-liste .card').textContent));
    check(true, 'photo ré-annotée pour la suite (export)');
  }

  console.log('6. Export .docx');
  {
    w.setTimeout = setTimeout; w.setInterval = setInterval; w.clearTimeout = clearTimeout; w.clearInterval = clearInterval; // horloge réelle pour JSZip
    const data = { notes: await w.Store.all('notes'), photos: await w.Store.all('photos'), schemas: await w.Store.all('schemas'), stage: { nom: 'Simon', expl: 'GAEC Test', lieu: 'Maine-et-Loire', maitre: 'M. Martin', obj: '40' }, joursStage: [w.Store.jourLocal()] };
    for (const org of ['rubrique', 'jour']) {
      const d = await w.Export.build(data, { org });
      if (process.env.DBG) console.log('   build ok');
      const blob = await w.Export.toBlob(d);
      if (process.env.DBG) console.log('   blob ok');
      const buf = await new Promise((res) => { const r = new w.FileReader(); r.onload = () => res(Buffer.from(r.result)); r.readAsArrayBuffer(blob); });
      const f = org === 'rubrique' ? OUTDOCX : OUTDOCX.replace('.docx', '-jour.docx');
      fs.writeFileSync(f, buf);
      check(buf.length > 2000 && buf.slice(0, 2).toString() === 'PK', 'docx (' + org + ') généré : ' + buf.length + ' octets');
    }
    // chemin natif complet : écriture dans Documents (base64) + partage
    $('e-go').click(); await until(() => /enregistré/.test($('e-msg').textContent), 300);
    check(/enregistré dans Documents/.test($('e-msg').textContent), 'export natif : ' + $('e-msg').textContent);
    const key = Object.keys(files).find((k) => /\.docx$/.test(k));
    check(key && Buffer.from(files[key].data, 'base64').slice(0, 2).toString() === 'PK', 'fichier écrit en base64 valide dans DOCUMENTS : ' + key);
  }

  console.log('7. Sauvegarde / restauration');
  {
    const o = await w.Store.exportAll();
    check(o.notes.length === 2 && o.photos.length === 1 && o.schemas.length === 1, 'export JSON : 2 notes, 1 photo, 1 schéma');
    const st2 = {}; const t2 = await boot('web', st2);
    const n = await t2.w.Store.importAll(JSON.parse(JSON.stringify(o)));
    const back = await t2.w.Store.all('notes');
    check(n >= 4 && back.length === 2, 'import dans une base vide : ' + back.length + ' notes restaurées');
    let rej = false; try { await t2.w.Store.importAll({ format: 'autre' }); } catch (e) { rej = true; }
    check(rej, 'fichier non reconnu refusé');
  }

  console.log('\n' + ok + ' réussis, ' + ko + ' échecs');
  process.exit(ko ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
