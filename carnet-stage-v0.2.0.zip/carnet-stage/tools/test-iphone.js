const { JSDOM } = require('jsdom'); const { IDBFactory } = require('fake-indexeddb');
(async()=>{
 let shared=null;
 const dom = await JSDOM.fromFile('/sessions/intelligent-quirky-curie/mnt/outputs/carnet/www/index.html',{runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,
  userAgent:'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148 Safari/604.1',
  beforeParse(w){ Object.defineProperty(w.navigator,'userAgent',{get:()=>'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148 Safari/604.1'}); w.indexedDB=new IDBFactory(); w.TextEncoder=TextEncoder; w.setImmediate=setImmediate;
   const ctx=new Proxy({}, {get:(t,k)=>typeof t[k]!=='undefined'?t[k]:()=>({width:1}),set:(t,k,v)=>{t[k]=v;return true}});
   w.HTMLCanvasElement.prototype.getContext=()=>ctx; w.HTMLCanvasElement.prototype.toDataURL=()=> 'data:image/png;base64,iVBORw0KGgo=';
   w.navigator.share=async(o)=>{shared=o}; w.navigator.canShare=()=>true; }});
 const w=dom.window,$=id=>w.document.getElementById(id);
 await new Promise(r=>{const i=setInterval(()=>{if(w.__carnetPret){clearInterval(i);r()}},20)});
 let ok=0,ko=0; const c=(x,m)=>{x?ok++:ko++;console.log((x?'  ok   ':'  ECHEC ')+m)};
 c(w.HW.IOS===true && !w.HW.NATIVE,'iPhone détecté, mode web');
 c($('n-mic').textContent==='Dicter (micro du clavier)','bouton : '+$('n-mic').textContent);
 $('n-mic').click(); await new Promise(r=>setTimeout(r,50));
 c(/micro en bas à droite du clavier/.test($('n-msg').textContent),'indice de dictée au clavier affiché');
 c(w.document.activeElement===$('n-texte'),'curseur placé dans la note');
 $('n-texte').value='essai'; $('n-save').click(); await new Promise(r=>setTimeout(r,200));
 $('e-go').click(); await new Promise(r=>{const i=setInterval(()=>{if($('partager-fichier')){clearInterval(i);r()}},50)});
 c(!!$('partager-fichier'),'bouton de partage affiché après génération');
 $('partager-fichier').click(); await new Promise(r=>setTimeout(r,200));
 c(shared&&shared.files&&/^Carnet_de_stage_.*\.docx$/.test(shared.files[0].name),'feuille de partage appelée avec '+(shared&&shared.files[0].name));
 console.log(ok+' réussis, '+ko+' échecs'); process.exit(ko?1:0);
})();
