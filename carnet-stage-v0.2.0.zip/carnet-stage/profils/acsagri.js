/* Profil de formation : seul fichier à changer pour adapter le carnet à une autre formation.
   Les rubriques viennent des documents de la formation (voir LISEZ-MOI : « Informations utilisées »). */
(function (root) {
  root.Profil = {
    id: 'acsagri',
    titre: 'Carnet de stage',
    sousTitre: 'BTSA ACS\'agri - stage en exploitation',
    fichier: 'Carnet_de_stage',
    objJours: 40,
    rubriques: [
      'Libre',
      'Documents de l\'exploitation (collecte)',
      'Combinaison productive (E6, fiche 1)',
      'Équipe de travail (E6, fiche 2)',
      'QHSE (E6, fiche 3)',
      'Données pour le projet (E7)',
      'Diagnostic territorial (E8)',
      'Questions pour l\'oral'
    ]
  };
})(typeof window !== 'undefined' ? window : globalThis);
