/* Profil : BTSA MVAOE (Julie). Source unique : « MVaoe_Fiche_collecte_projet_stage_2425.docx ».
   Rubriques = documents à rendre par épreuve (E4 à E8) et documents à réunir auprès de l'entreprise.
   Les valeurs de `defauts` viennent de la fiche de collecte ; elles restent modifiables dans Réglages. */
(function (root) {
  root.Profil = {
    id: 'mvaoe',
    titre: 'Carnet de stage',
    sousTitre: 'BTSA MVAOE - stage en entreprise',
    fichier: 'Carnet_de_stage_MVAOE',
    objJours: 40,
    defauts: {
      nom: 'Julie Gamart',
      expl: 'Pépinières Crosnier',
      lieu: 'Nazelles-Négron (37)',
      maitre: 'Arnaud Crosnier',
      debut: '2026-10-19',
      fin: '2026-10-30',
      obj: '40'
    },
    rubriques: [
      'Libre',
      'Documents de l\'entreprise (comptes, documents techniques, organisation)',
      'E4 - Système de culture spécialisée (fiche)',
      'E5 - Organisation du milieu de production (fiche 1)',
      'E5 - IEMO dans l\'environnement de production (fiche 2)',
      'E6 - Organisation du travail (fiche 1)',
      'E6 - Gestion de l\'activité de production (fiche 2)',
      'E6 - Problématique QSE (fiche 3)',
      'E7 - Pilotage stratégique (dossier et synthèse)',
      'E8 - Situation vécue en lien avec la production (fiche 1)',
      'E8 - Plan d\'action, accompagnement au changement technique (fiche 2)'
    ]
  };
})(typeof window !== 'undefined' ? window : globalThis);
