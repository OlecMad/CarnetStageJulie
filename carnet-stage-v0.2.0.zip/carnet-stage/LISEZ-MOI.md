# Carnet de stage — BTSA ACS'agri

Application Android (Capacitor, même chaîne de fabrication que DiagFluvial) :
notes dictées transcrites en texte, photos horodatées, schémas à main levée,
compilation en .docx à la fin du stage.

## Installer (GitHub Actions, comme DiagFluvial)

1. Créer un dépôt GitHub vide (par exemple `carnet-stage`).
2. Y déposer l'archive `carnet-stage-v0.1.0.zip` telle quelle (« uploading an existing file »).
3. Créer le fichier `.github/workflows/android.yml` avec le contenu du fichier `android.yml` fourni.
4. Onglet Actions : attendre la fin de « Construire l'APK » (5 à 15 min la première fois).
5. Télécharger l'artefact `carnet-stage-debug` (zip contenant l'APK) et installer l'APK.
   L'application s'installe à côté de DiagFluvial (identifiant `fr.lileauvert.carnetstage`).

## Premier essai à faire sur le téléphone

Réglages > Diagnostic de la dictée > « Vérifier l'appareil » puis « Essai de 10 secondes ».
Le journal affiché sous les boutons indique ce que fait le moteur de reconnaissance.

## Ce qui a été vérifié ici, et ce qui ne l'a pas été

Vérifié (tools/test-carnet.js, 39 contrôles) : logique de dictée avec un plugin simulé,
notes, photos, schémas, sauvegarde, génération du .docx (relu avec python-docx),
`npx cap sync android` (4 plugins reconnus).
Non vérifié : compilation Gradle (pas de SDK Android ici), dictée réelle sur le
téléphone, appareil photo réel, écriture réelle dans Documents.

## iPhone (version web installable)

Le dossier `www` est une application web complète (manifeste, cache hors ligne). Sur iPhone :
dictée par le micro du clavier iOS (la reconnaissance vocale web n'est pas disponible dans une web app
de l'écran d'accueil, rapport WebKit 225298), photos par l'appareil photo, schémas au doigt,
export .docx par la feuille de partage (Fichiers, Mail, AirDrop).

1. Créer un dépôt GitHub **public** (GitHub Pages sur dépôt privé : vérifier les conditions du compte).
2. Y déposer le contenu de `carnet-stage-iphone.zip` extrait (index.html, les .js, manifest.json, sw.js, dossiers `icons` et `vendor`).
3. Settings > Pages > « Deploy from a branch » > `main` / `(root)` > Save. L'adresse est
   `https://<compte>.github.io/<dépôt>/`.
4. Sur l'iPhone, ouvrir l'adresse dans Safari > Partager > « Sur l'écran d'accueil ».
5. Ouvrir une première fois avec du réseau (mise en cache), puis l'appli fonctionne hors ligne.

Seul le code est public ; notes, photos et schémas restent dans le téléphone.
Vérifié : simulation iPhone dans jsdom (tools/test-iphone.js). Non vérifié : un vrai iPhone.

## Nouveauté 0.2.0
Annotation directe des photos (stylo, formes, texte, gomme, annuler) : bouton « Annoter » sur chaque photo.
La photo d'origine est conservée, l'annotation peut être modifiée ou retirée. Le .docx reprend la photo annotée.
Contenu propre à la formation : `www/profil.js`. Détail des informations utilisées : `INFORMATIONS_UTILISEES.md`.
