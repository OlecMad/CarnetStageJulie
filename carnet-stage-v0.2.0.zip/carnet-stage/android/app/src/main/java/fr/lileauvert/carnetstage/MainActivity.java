package fr.lileauvert.carnetstage;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
