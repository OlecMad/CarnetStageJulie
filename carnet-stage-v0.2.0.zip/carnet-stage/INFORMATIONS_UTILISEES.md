# Informations utilisées pour le carnet de Simon (BTSA ACS'agri)

| Information | Source | Où elle est dans l'application |
|---|---|---|
| 40 jours minimum (8 semaines) ; 10 jours cultures + 10 jours productions animales avant le 15 mars 2027 ; 30 jours avant septembre 2027 | e-campus, cours « Parcours de formation 2 ans - BTS ACS'AGRI - Examen 28 », pages stage | Compteur « Jours : n / 40 », Réglages |
| Étapes du stage : trouver l'exploitation, fiche de collecte, saisie de la fiche projet 3 semaines avant, validation CERCA, 4 documents de fin de stage | e-campus, pages stage | Non intégré à l'application (suivi dans le tableau de bord) |
| Documents à réunir : dossier de gestion (3 exercices minimum), annuités et amortissements, marges brutes, références de groupe, documents techniques (IVV, IC, GMQ, IFT), aides PAC | e-campus, fiche « collecte d'informations pour projet de stage » | Rubrique « Documents de l'exploitation (collecte) » |
| E6 : 3 fiches de 2 pages issues du vécu (combinaison productive, management d'un collectif, démarche QHSE), oral de 30 min | e-campus, méthodologie E6 (note de service DGER/SDES/2024-410) | Rubriques « Combinaison productive », « Équipe de travail », « QHSE » |
| E8 : diagnostic territorial, 3 fiches, noter questions et idées pour l'entretien | e-campus, méthodologie E8 | Rubriques « Diagnostic territorial (E8) », « Questions pour l'oral » |
| E7 : recueil de données pour le projet | tableau de suivi (jalons) ; le corps de la méthodologie n'a pas pu être extrait | Rubrique « Données pour le projet (E7) » (à confirmer) |
| Envies : notes vocales transcrites, photos horodatées, schémas type Concepts, compilation .docx en fin de stage, annotation des photos | Demande de Simon | Notes, Photo, Schéma, Export |
| Architecture technique, chaîne de fabrication GitHub Actions | APK DiagFluvial v1.6.0, dossier de reprise, PROCEDURE_INSTALLATION.md | Projet Capacitor, android.yml |
| Comportement du plugin de dictée | README et code Java de @capacitor-community/speech-recognition 7.0.1 | Module de dictée corrigé |

Non pris en compte : les corps des fiches E6 et E8 (modèles de fiches), la fiche de collecte « stage » en .docx.
Aucune information sur la formation de Julie (Métiers du végétal) n'a été utilisée.

## Adapter à une autre formation
Seul `www/profil.js` change : titre, sous-titre, nom de fichier, nombre de jours, liste des rubriques.
Pour une APK distincte : nouvel identifiant d'application dans `capacitor.config.json`, `android/app/build.gradle` et `strings.xml`.
